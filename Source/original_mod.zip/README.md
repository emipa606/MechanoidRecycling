# Mechanoid Recycling mod for RimWorld

targetVersion 0.18.1722

You dont know what to do with death mechanoids? Recycle them! Detach bionic arms and legs or full disassemle on electric and hull parts.

You can disassemble mechanoids into its component parts and create of them bionic prostheses.
